import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';


@Component({
  selector: 'app-guest',
  templateUrl: './guest.component.html',
  styleUrls: ['./guest.component.css']
})
export class GuestComponent implements OnInit {

  currentTime: any;
  /* duration: any;
  hours: any; */

  constructor() { }

  ngOnInit() {
    this.currentTime = moment().format('MMMM Do YYYY, h:mm:ss a')
     /* var duration = moment.duration(end.diff());
      var hours = duration.asHours();  */
     /*  let myArr1: any[] ;
  
      myArr1= [
        {
          Name:'Robin',
          Contact_no: '1234567890',
          Time_in: '10pm',
          Waiting_time: '',
          Assigned_to: ''
        },
        {
          Name:'Krishna',
          Contact_no: '1234567890',
          Time_in: '11pm',
          Waiting_time: '',
          Assigned_to: ''
        },
        {
          Name:'Anshu',
          Contact_no: '0987654321',
          Time_in: '12pm',
          Waiting_time: '',
          Assigned_to: ''
        },
        {
          Name:'Ashmit',
          Contact_no: '5457452212',
          Time_in: '5pm',
          Waiting_time: '',
          Assigned_to: ''
        },
      ];

      for (let entry of myArr1) {
        entry :[] 
      //  console.log(entry); // 1, "string", false
        for(let gg of entry){
          console.log(gg.Contact_no);
        }
    } */
  }

  data= [
    {
      Name:'Robin',
      Contact_no: '1234567890',
      Time_in: '10pm',
      Waiting_time: '',
      Assigned_to: ''
    },
    {
      Name:'Krishna',
      Contact_no: '1234567890',
      Time_in: '11pm',
      Waiting_time: '',
      Assigned_to: ''
    },
    {
      Name:'Anshu',
      Contact_no: '0987654321',
      Time_in: '12pm',
      Waiting_time: '',
      Assigned_to: ''
    },
    {
      Name:'Ashmit',
      Contact_no: '5457452212',
      Time_in: '5pm',
      Waiting_time: '',
      Assigned_to: ''
    },
  ];
  


 
}
